﻿namespace WebApplication2.Models
{
    public class Car
    {
        public int ID { get; set; }
        public string Type { get; set; }
        public int Year { get; set; }

        public override string ToString()
        {
            return $"{ID} , {Type} , {Year}";
        }
    }
}
