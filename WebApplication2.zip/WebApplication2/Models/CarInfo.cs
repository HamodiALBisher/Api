﻿namespace WebApplication2.Models
{
    public class CarInfo
    {
        public int ID { get; set; }
    }
}
