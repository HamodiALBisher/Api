﻿using System.Data.SqlClient;

namespace WebApplication2.Models
{
    public class DataBaseService
    {
        static string connection = @"Data Source=DESKTOP-JB3G1JI\SQLEXPRESS01;Database=Car;Integrated Security=True;Connect Timeout=30;Encrypt=True;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public static Car returnCar(int id)
        {
            Car car = null;
            try
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    string query = "Select * From Cars Where CarID = @CarID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CarID", id);

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        car = new Car()
                        {
                            ID = (int)reader["CarID"],
                            Type = reader["CarType"].ToString(),
                            Year = (int)reader["YearOfProduction"]
                        };
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                LogSqlException(sqlEx);
                throw new Exception("A database error occurred: " + sqlEx.Message, sqlEx);
            }
            catch (Exception ex)
            {
                LogException(ex);
                throw new Exception("An error occurred while retrieving car information: " + ex.Message, ex);
            }
            return car;
        }

        public static List<Car> GetAllCars()
        {
            List<Car> cars = new List<Car>();
            try
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    string query = "SELECT * FROM Cars";
                    SqlCommand cmd = new SqlCommand(query, con);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Car car = new Car()
                        {
                            ID = (int)reader["CarID"],
                            Type = reader["CarType"].ToString(),
                            Year = (int)reader["YearOfProduction"]
                        };
                        cars.Add(car);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                LogSqlException(sqlEx);
                throw new Exception("A database error occurred: " + sqlEx.Message, sqlEx);
            }
            catch (Exception ex)
            {
                LogException(ex);
                throw new Exception("An error occurred while retrieving car information: " + ex.Message, ex);
            }
            return cars;
        }

        public static void AddCar(Car car)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    string query = "INSERT INTO Cars (CarType, YearOfProduction) VALUES (@CarType, @YearOfProduction)";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CarType", car.Type);
                    cmd.Parameters.AddWithValue("@YearOfProduction", car.Year);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (SqlException sqlEx)
            {
                LogSqlException(sqlEx);
                throw new Exception("A database error occurred: " + sqlEx.Message, sqlEx);
            }
            catch (Exception ex)
            {
                LogException(ex);
                throw new Exception("An error occurred while adding a car: " + ex.Message, ex);
            }
        }

        public static void DeleteCar(int id)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    string query = "DELETE FROM Cars WHERE CarID = @CarID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CarID", id);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (SqlException sqlEx)
            {
                LogSqlException(sqlEx);
                throw new Exception("A database error occurred: " + sqlEx.Message, sqlEx);
            }
            catch (Exception ex)
            {
                LogException(ex);
                throw new Exception("An error occurred while deleting a car: " + ex.Message, ex);
            }
        }

        public static void EditCar(Car car)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    string query = "UPDATE Cars SET CarType = @CarType, YearOfProduction = @YearOfProduction WHERE CarID = @CarID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CarID", car.ID);
                    cmd.Parameters.AddWithValue("@CarType", car.Type);
                    cmd.Parameters.AddWithValue("@YearOfProduction", car.Year);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (SqlException sqlEx)
            {
                LogSqlException(sqlEx);
                throw new Exception("A database error occurred: " + sqlEx.Message, sqlEx);
            }
            catch (Exception ex)
            {
                LogException(ex);
                throw new Exception("An error occurred while editing a car: " + ex.Message, ex);
            }
        }

        public static string TestConnection()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();
                    return "Connection successful";
                }
            }
            catch (Exception ex)
            {
                return "Connection failed: " + ex.Message;
            }
        }

        private static void LogSqlException(SqlException ex)
        {
            // Log detailed SQL exception information for further analysis
            Console.WriteLine("SQL Error: " + ex.Message);
            foreach (SqlError error in ex.Errors)
            {
                Console.WriteLine($"Error Number: {error.Number}, Message: {error.Message}");
            }
        }

        private static void LogException(Exception ex)
        {
            // Log detailed exception information for further analysis
            Console.WriteLine("Error: " + ex.Message);
        }
    }
}

