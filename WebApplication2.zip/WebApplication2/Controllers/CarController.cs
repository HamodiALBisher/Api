﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarController : ControllerBase
    {
        [HttpGet("CarInfo/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Car))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult CarInfo(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid car ID.");
            }

            try
            {
                Car car = DataBaseService.returnCar(id);
                if (car != null)
                {
                    return Ok(car);
                }
                else
                {
                    return NotFound("There is no car with this info.");
                }
            }
            catch (Exception e)
            {
                return BadRequest("Error: " + e.Message);
            }
        }
        // Test connection 
        [HttpGet("TestConnection")]
        public IActionResult TestConnection()
        {
            return Ok(DataBaseService.TestConnection());
        }

        // Get all cars 
        [HttpGet("AllCars")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<Car>))]
        public IActionResult GetAllCars()
        {
            try
            {
                List<Car> cars = DataBaseService.GetAllCars();
                return Ok(cars);
            }
            catch (Exception e)
            {
                return BadRequest("Error: " + e.Message);
            }
        }

        // Add a car 
        [HttpPost("AddCar")]
        [ProducesResponseType(StatusCodes.Status201Created, Type = typeof(Car))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult AddCar([FromBody] Car car)
        {
            if (car == null || string.IsNullOrEmpty(car.Type) || car.Year <= 0)
            {
                return BadRequest("Invalid car information.");
            }

            try
            {
                DataBaseService.AddCar(car);
                return CreatedAtAction(nameof(CarInfo), new { id = car.ID }, car);
            }
            catch (Exception e)
            {
                return BadRequest("Error: " + e.Message);
            }
        }

        // Delete a car 
        [HttpDelete("DeleteCar/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult DeleteCar(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid car ID.");
            }

            try
            {
                DataBaseService.DeleteCar(id);
                return Ok("Car deleted successfully.");
            }
            catch (Exception e)
            {
                return BadRequest("Error: " + e.Message);
            }
        }

        // Edit a car 
        [HttpPut("EditCar")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Car))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult EditCar([FromBody] Car car)
        {
            if (car == null || car.ID <= 0 || string.IsNullOrEmpty(car.Type) || car.Year <= 0)
            {
                return BadRequest("Invalid car information.");
            }

            try
            {
                DataBaseService.EditCar(car);
                return Ok(car);
            }
            catch (Exception e)
            {
                return BadRequest("Error: " + e.Message);
            }
        }
    }
}
